
@extends('layouts.admin')

@section('content')
    <h1>Bantuan</h1>
    <p>Help page for employees.</p>
@endsection
