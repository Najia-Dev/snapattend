

<?php $__env->startSection('content'); ?>
<div class="data-absensi">
    <h1>Data Absensi</h1>

    <!-- Form Filter Dropdowns -->
    <form method="GET" action="<?php echo e(route('admin.dataAbsensi')); ?>">
        <div class="row mb-4">
            <div class="col-md-3">
                <label for="tanggal">Pilih Tanggal:</label>
                <input type="date" name="tanggal" id="tanggal" class="form-control" value="<?php echo e(request('tanggal')); ?>">
            </div>
            <div class="col-md-3">
                <label for="bulan">Pilih Bulan:</label>
                <select name="bulan" id="bulan" class="form-control">
                    <?php $__currentLoopData = ['01' => 'Januari', '02' => 'Februari', '03' => 'Maret', '04' => 'April', '05' => 'Mei', '06' => 'Juni', '07' => 'Juli', '08' => 'Agustus', '09' => 'September', '10' => 'Oktober', '11' => 'November', '12' => 'Desember']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $num => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($num); ?>" <?php echo e(request('bulan') == $num ? 'selected' : ''); ?>><?php echo e($name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-3">
                <label for="tahun">Pilih Tahun:</label>
                <select name="tahun" id="tahun" class="form-control">
                    <?php for($i = 2020; $i <= date('Y'); $i++): ?>
                        <option value="<?php echo e($i); ?>" <?php echo e(request('tahun') == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label for="unit">Pilih Unit:</label>
                <select name="unit" id="unit" class="form-control">
                    <option value="kupp" <?php echo e(request('unit') == 'kupp' ? 'selected' : ''); ?>>KUPP</option>
                    <option value="tk" <?php echo e(request('unit') == 'tk' ? 'selected' : ''); ?>>TK</option>
                    <option value="sd" <?php echo e(request('unit') == 'sd' ? 'selected' : ''); ?>>SD</option>
                    <option value="smp" <?php echo e(request('unit') == 'smp' ? 'selected' : ''); ?>>SMP</option>
                    <option value="sma" <?php echo e(request('unit') == 'sma' ? 'selected' : ''); ?>>SMA</option>
                    <option value="smk" <?php echo e(request('unit') == 'smk' ? 'selected' : ''); ?>>SMK</option>
                </select>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <button type="submit" class="btn btn-primary mt-2">Tampilkan Data</button>
            </div>
        </div>
    </form>

    <!-- Tombol Export -->
    <form method="GET" action="<?php echo e(route('admin.exportAbsensi')); ?>" style="margin-top: 10px;">
        <input type="hidden" name="tanggal" value="<?php echo e(request('tanggal')); ?>">
        <input type="hidden" name="bulan" value="<?php echo e(request('bulan')); ?>">
        <input type="hidden" name="tahun" value="<?php echo e(request('tahun')); ?>">
        <input type="hidden" name="unit" value="<?php echo e(request('unit')); ?>">
        <button type="submit" class="btn btn-success">Export</button>
    </form>

    <!-- Tombol Hide/Show Tabel -->
    <button id="toggleTable" class="btn btn-secondary mb-3">Hide Tabel</button>

    <!-- Tabel Data Absensi -->
    <div class="table-responsive" id="tableAbsensi">
        <table class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Karyawan</th>
                    <th>Unit</th>
                    <th>Masuk</th>
                    <th>Istirahat</th>
                    <th>Pulang</th>
                    <th>Tanggal Absensi</th>
                </tr>
            </thead>
            <tbody>
                <?php if(count($absensiData) > 0): ?>
                    <?php $__currentLoopData = $absensiData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e($data->nama_karyawan); ?></td>
                            <td><?php echo e($data->unit); ?></td>
                            <td><?php echo e($data->masuk); ?></td>
                            <td><?php echo e($data->istirahat); ?></td>
                            <td><?php echo e($data->pulang); ?></td>
                            <td><?php echo e($data->tanggal_absensi); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="text-center">Data absensi tidak tersedia</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination cleaned of any large icons -->
    <div class="d-flex justify-content-center">
        <?php echo e($absensiData->appends(request()->query())->links()); ?>

    </div>

    <!-- Tabel Absensi Darurat -->
    <div class="table-responsive mt-5">
        <h2>Absensi Darurat</h2>

        <!-- Form untuk Absensi Darurat -->
        <form method="POST" action="<?php echo e(route('absensi_darurat.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="row mb-4">
                <div class="col-md-3">
                    <label for="bulan">Pilih Bulan:</label>
                    <select name="bulan" id="bulan" class="form-control">
                        <?php $__currentLoopData = ['01' => 'Januari', '02' => 'Februari', '03' => 'Maret', '04' => 'April', '05' => 'Mei', '06' => 'Juni', '07' => 'Juli', '08' => 'Agustus', '09' => 'September', '10' => 'Oktober', '11' => 'November', '12' => 'Desember']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $num => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($num); ?>" <?php echo e(request('bulan') == $num ? 'selected' : ''); ?>><?php echo e($name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label for="tahun">Pilih Tahun:</label>
                    <select name="tahun" id="tahun" class="form-control">
                        <?php for($i = 2020; $i <= date('Y'); $i++): ?>
                            <option value="<?php echo e($i); ?>" <?php echo e(request('tahun') == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
            </div>
            <button type="submit" class="btn btn-success mb-4">Tampilkan</button>
        </form>

        <!-- Tombol Hide/Show Tabel Darurat -->
        <button id="toggleTableDarurat" class="btn btn-secondary btn-sm mb-3">Hide Tabel</button>

        <!-- Tabel Data Absensi Darurat -->
        <div id="tableDarurat" class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Karyawan</th>
                        <th>Unit</th>
                        <th>Alasan Darurat</th>
                        <th>Foto Bukti</th>
                        <th>Tanggal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $absensiDarurat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $darurat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e($darurat->nama_karyawan); ?></td>
                            <td><?php echo e($darurat->unit); ?></td>
                            <td><?php echo e($darurat->alasan); ?></td>
                            <td>
                                <?php if($darurat->foto): ?>
                                <img src="<?php echo e(asset('storage/' . $darurat->foto)); ?>" alt="Bukti Foto" width="100" height="100">
                                <?php else: ?>
                                    Tidak ada bukti
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($darurat->tanggal); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Tabel Izin -->
    <div class="table-responsive mt-5">
        <h2>Izin</h2>

        <!-- Form untuk Izin -->
        <form method="POST" action="<?php echo e(route('izin.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="row mb-4">
                <div class="col-md-3">
                    <label for="bulan">Pilih Bulan:</label>
                    <select name="bulan" id="bulan" class="form-control">
                        <?php $__currentLoopData = ['01' => 'Januari', '02' => 'Februari', '03' => 'Maret', '04' => 'April', '05' => 'Mei', '06' => 'Juni', '07' => 'Juli', '08' => 'Agustus', '09' => 'September', '10' => 'Oktober', '11' => 'November', '12' => 'Desember']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $num => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($num); ?>" <?php echo e(request('bulan') == $num ? 'selected' : ''); ?>><?php echo e($name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label for="tahun">Pilih Tahun:</label>
                    <select name="tahun" id="tahun" class="form-control">
                        <?php for($i = 2020; $i <= date('Y'); $i++): ?>
                            <option value="<?php echo e($i); ?>" <?php echo e(request('tahun') == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
            </div>
            <button type="submit" class="btn btn-success mb-4">Tampilkan</button>
        </form>

        <!-- Tombol Hide/Show Tabel Izin -->
        <button id="toggleTableIzin" class="btn btn-secondary btn-sm mb-3">Hide Tabel</button>

        <!-- Tabel Data Izin -->
        <div id="tableIzin" class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Karyawan</th>
                        <th>Unit</th>
                        <th>Alasan Izin</th>
                        <th>Lampiran Foto</th>
                        <th>Tanggal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $izin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $izinItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e($izinItem->nama_karyawan); ?></td>
                            <td><?php echo e($izinItem->unit); ?></td>
                            <td><?php echo e($izinItem->alasan); ?></td>
                            <td>
                                <?php if($izinItem->lampiran_foto): ?>
                                <img src="<?php echo e(asset('storage/' . $izinItem->lampiran_foto)); ?>" alt="Lampiran Foto" width="100" height="100">
                                <?php else: ?>
                                    Tidak ada lampiran
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($izinItem->tanggal); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- CSS untuk memperbaiki z-index dan margin -->
<style>
    .ui-datepicker {
        z-index: 10000 !important;
    }

    .data-absensi {
        margin-top: 20px;
    }

    .datepicker {
        margin-bottom: 20px;
    }

    #toggleTable {
        margin-top: 10px;
    }

    .table-responsive {
        margin-top: 30px;
    }

    /* Hide large icons from pagination */
    .pagination .page-item .page-link svg {
        display: none !important;
    }
</style>

<!-- Load jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Script for toggling the table visibility -->
<script>
    $(document).ready(function() {
        $('#toggleTable').on('click', function() {
            $('#tableAbsensi').toggle();
            if ($('#tableAbsensi').is(':visible')) {
                $(this).text('Hide Tabel');
            } else {
                $(this).text('Show Tabel');
            }
        });

        $('#toggleTableDarurat').on('click', function() {
            $('#tableDarurat').toggle();
            if ($('#tableDarurat').is(':visible')) {
                $(this).text('Hide Tabel');
            } else {
                $(this).text('Show Tabel');
            }
        });

        $('#toggleTableIzin').on('click', function() {
            $('#tableIzin').toggle();
            if ($('#tableIzin').is(':visible')) {
                $(this).text('Hide Tabel');
            } else {
                $(this).text('Show Tabel');
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\snapattend\resources\views/admin/data-absensi.blade.php ENDPATH**/ ?>