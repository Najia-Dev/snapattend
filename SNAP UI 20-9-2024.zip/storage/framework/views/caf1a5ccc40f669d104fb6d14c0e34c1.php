

<?php $__env->startSection('content'); ?>
<div class="edit-user">
    <h1>Edit User</h1>

    <form action="<?php echo e(route('admin.updateUser', $user->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="name">Nama</label>
            <input type="text" name="name" id="name" class="form-control" value="<?php echo e($user->name); ?>" required>
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" name="email" id="email" class="form-control" value="<?php echo e($user->email); ?>" required>
        </div>
        <div class="form-group">
            <label for="role">Role</label>
            <select name="role" id="role" class="form-control" required>
                <option value="admin" <?php echo e($user->role == 'admin' ? 'selected' : ''); ?>>Admin</option>
                <option value="karyawan" <?php echo e($user->role == 'karyawan' ? 'selected' : ''); ?>>Karyawan</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary mt-3">Perbarui User</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\snapattend\resources\views/admin/edit-user.blade.php ENDPATH**/ ?>